"""
Discord Server Manager Bot Package
"""
__version__ = "1.0.0"