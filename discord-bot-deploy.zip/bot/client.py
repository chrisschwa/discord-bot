"""
Bot client - discord.py interaction client with cog loading.
"""
import logging
import pkg_resources
import discord
from discord import app_commands
from discord.ext import commands

from bot.config import Config
from bot.database import Database

logger = logging.getLogger("bot")


class BotClient(commands.Bot):
    """Custom bot client with database and cog management."""

    def __init__(self, config: Config):
        # Define intents
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        intents.guilds = True
        intents.voice_states = True
        intents.guild_reactions = True

        # Command prefix (secondary to slash commands)
        prefix = config.PREFIX

        super().__init__(
            command_prefix=prefix,
            intents=intents,
            help_command=None,
        )

        self.config = config
        self.db = Database()

        # Setup sync flag for syncing slash commands on startup
        self._sync_commands = True

    async def setup_hook(self):
        """Called when the bot is ready to load cogs."""
        # Initialize database
        await self.db.connect()
        logger.info("Database connected successfully.")

        # Load all cogs from bot/cogs/
        cog_dir = "bot.cogs"
        # Get the cogs package directory
        import importlib
        import os
        
        cogs_package = importlib.import_module(cog_dir)
        cogs_path = os.path.dirname(cogs_package.__file__)
        
        for filename in os.listdir(cogs_path):
            if filename.endswith(".py") and not filename.startswith("_"):
                cog_name = filename[:-3]  # Remove .py
                try:
                    await self.load_extension(f"{cog_dir}.{cog_name}")
                    logger.info(f"Loaded cog: {cog_name}")
                except Exception as e:
                    logger.error(f"Failed to load cog {cog_name}: {e}")

        logger.info("All cogs loaded.")

    async def on_ready(self):
        """Called when the bot has logged in."""
        logger.info(f"Logged in as {self.user} (ID: {self.user.id})")
        logger.info(f"Connected to {len(self.guilds)} guilds")

        # Sync slash commands to guilds
        if self._sync_commands:
            try:
                for guild in self.guilds:
                    synced = await self.tree.sync(guild=guild)
                    logger.info(f"Synced {len(synced)} slash commands to {guild.name}")
                # Also sync globally (new global commands take up to 1hr to propagate)
                global_synced = await self.tree.sync()
                logger.info(f"Synced {len(global_synced)} slash commands globally")
            except Exception as e:
                logger.error(f"Failed to sync commands: {e}")
            finally:
                self._sync_commands = False

    async def on_member_join(self, member: discord.Member):
        """Event: member joins the guild."""
        # Handled by welcome cog, but ensure event is received
        pass

    async def on_member_remove(self, member: discord.Member):
        """Event: member leaves the guild."""
        pass

    async def on_reaction_add(self, reaction: discord.Reaction, user: discord.User):
        """Event: reaction added to a message."""
        if user.bot:
            return
        # Handled by reaction roles cog
        pass

    async def on_reaction_remove(self, reaction: discord.Reaction, user: discord.User):
        """Event: reaction removed from a message."""
        if user.bot:
            return
        # Handled by reaction roles cog
        pass

    async def on_voice_state_update(
        self, member, before: discord.VoiceState, after: discord.VoiceState
    ):
        """Event: voice state changed."""
        # Handled by voice channels cog
        pass

    async def on_message(self, message):
        """Event: message received."""
        if message.author.bot:
            return
        
        # Process bot commands
        await self.process_commands(message)

    async def on_command_error(self, ctx, error):
        """Global command error handler."""
        if isinstance(error, commands.CommandNotFound):
            return
        elif isinstance(error, app_commands.AppCommandError):
            original = error.original
            if isinstance(original, discord.Forbidden):
                await ctx.send("❌ I don't have permission to do that.")
            elif isinstance(original, discord.NotFound):
                await ctx.send("❌ The resource was not found.")
            else:
                logger.error(f"Command error in {ctx.command}: {error}", exc_info=error)
                await ctx.send("❌ An error occurred while processing the command.", ephemeral=True)
        else:
            logger.error(f"Command error in {ctx.command}: {error}", exc_info=error)
            try:
                await ctx.send("❌ An error occurred while processing the command.", ephemeral=True)
            except Exception:
                pass

    async def close(self):
        """Clean shutdown."""
        await self.db.close()
        logger.info("Database connection closed.")
        await super().close()